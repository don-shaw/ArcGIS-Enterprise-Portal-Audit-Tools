from arcgis.widgets._mapview._raster.local_raster_overlay_manager \
    import LocalRasterOverlayManager, RasterOverlay
